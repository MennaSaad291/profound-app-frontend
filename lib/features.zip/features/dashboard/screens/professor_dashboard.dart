import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

const String _base = 'http://127.0.0.1:8000';

class ProfessorDashboard extends StatefulWidget {
  const ProfessorDashboard({super.key});
  @override
  State<ProfessorDashboard> createState() => _ProfessorDashboardState();
}

class _ProfessorDashboardState extends State<ProfessorDashboard> {
  Map<String, dynamic>? dashboardData;
  bool isLoading = true;
  int? userId;
  String professorName = "Professor";

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final args = ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
    userId = args?['id'];
    professorName = args?['name'] ?? "Professor";
    if (userId != null && dashboardData == null) _fetchDashboard();
  }

  Future<void> _fetchDashboard() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse('$_base/dashboard/$userId'));
      if (res.statusCode == 200) {
        setState(() { dashboardData = jsonDecode(res.body); isLoading = false; });
      } else {
        setState(() => isLoading = false);
      }
    } catch (_) { setState(() => isLoading = false); }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: [Color(0xFFF5F3FF), Colors.white, Color(0xFFFFFBEB)],
        ),
      ),
      child: isLoading
        ? const Center(child: CircularProgressIndicator(color: Color(0xFF9333EA)))
        : RefreshIndicator(
            onRefresh: _fetchDashboard,
            child: CustomScrollView(slivers: [
              SliverToBoxAdapter(child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  // Welcome header
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [Color(0xFF9333EA), Color(0xFF4F46E5)]),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(children: [
                      Container(
                        width: 56, height: 56,
                        decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), shape: BoxShape.circle),
                        child: const Icon(Icons.person, color: Colors.white, size: 30),
                      ),
                      const SizedBox(width: 16),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text("Welcome back,", style: const TextStyle(color: Colors.white70, fontSize: 13)),
                        Text("Prof. $professorName",
                          style: GoogleFonts.inter(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                        const Text("Here's your academic overview",
                          style: TextStyle(color: Colors.white70, fontSize: 12)),
                      ])),
                    ]),
                  ),
                  const SizedBox(height: 24),

                  // Stats grid
                  _buildSectionHeader("Overview"),
                  const SizedBox(height: 12),
                  GridView.count(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    crossAxisCount: 2,
                    crossAxisSpacing: 12, mainAxisSpacing: 12,
                    childAspectRatio: 1.5,
                    children: [
                      _statCard("Total Courses", "${dashboardData?['total_courses'] ?? 0}",
                        Icons.book, const Color(0xFF9333EA)),
                      _statCard("Active Courses", "${dashboardData?['active_courses'] ?? 0}",
                        Icons.play_circle, const Color(0xFF10B981)),
                      _statCard("Total Students", "${dashboardData?['total_students'] ?? 0}",
                        Icons.people, const Color(0xFF4F46E5)),
                      _statCard("At-Risk", "${dashboardData?['at_risk_students'] ?? 0}",
                        Icons.warning_amber, Colors.red),
                    ],
                  ),
                  const SizedBox(height: 24),

                  // Current Workload
                  _buildSectionHeader("Current Workload"),
                  const SizedBox(height: 12),
                  _buildWorkloadCard(
                    label: "Class Average Grade",
                    value: dashboardData?['avg_grade'] ?? "N/A",
                    icon: Icons.bar_chart, color: Colors.green,
                  ),
                  const SizedBox(height: 12),
                  _buildWorkloadCard(
                    label: "At-Risk Students",
                    value: "${dashboardData?['at_risk_students'] ?? 0}",
                    subtext: "Students need attention",
                    icon: Icons.error_outline, color: Colors.amber,
                    buttonText: "View Analytics",
                    onButtonPressed: () => Navigator.pushNamed(context, '/analytics',
                      arguments: {'id': userId}),
                  ),
                  const SizedBox(height: 12),
                  _buildWorkloadCard(
                    label: "My Courses",
                    value: "${dashboardData?['total_courses'] ?? 0}",
                    subtext: "Courses this semester",
                    icon: Icons.school, color: Colors.blue,
                    linkText: "Manage Courses →",
                    onLinkPressed: () => Navigator.pushNamed(context, '/courses',
                      arguments: {'id': userId}),
                  ),
                  const SizedBox(height: 24),

                  // Recent courses
                  if ((dashboardData?['courses'] as List?)?.isNotEmpty == true) ...[
                    _buildSectionHeader("My Courses"),
                    const SizedBox(height: 12),
                    ...(dashboardData!['courses'] as List).take(3).map((c) => _buildCourseTile(c)),
                    if ((dashboardData!['courses'] as List).length > 3)
                      TextButton(
                        onPressed: () => Navigator.pushNamed(context, '/courses', arguments: {'id': userId}),
                        child: const Text("View all courses →", style: TextStyle(color: Color(0xFF9333EA))),
                      ),
                    const SizedBox(height: 16),
                  ],

                  // Quick Actions
                  _buildSectionHeader("Quick Actions"),
                  const SizedBox(height: 12),
                  _buildFeatureButton(
                    title: "AI Exam Generator",
                    subtitle: "Create assessments with Bloom's taxonomy",
                    icon: Icons.edit_note,
                    gradient: const [Color(0xFF4F46E5), Color(0xFF4338CA)],
                    onTap: () => Navigator.pushNamed(context, '/exam_generator', arguments: {'id': userId}),
                  ),
                  const SizedBox(height: 12),
                  _buildFeatureButton(
                    title: "Generate Lecture Materials",
                    subtitle: "AI-powered content creation",
                    icon: Icons.menu_book,
                    gradient: const [Color(0xFFF59E0B), Color(0xFFD97706)],
                    onTap: () => Navigator.pushNamed(context, '/generate_lecture'),
                  ),
                  const SizedBox(height: 12),
                  _buildFeatureButton(
                    title: "AI Grading System",
                    subtitle: "Automated grading with NLP",
                    icon: Icons.check_circle_outline,
                    gradient: const [Color(0xFF9333EA), Color(0xFF7E22CE)],
                    onTap: () => Navigator.pushNamed(context, '/grading'),
                  ),
                  const SizedBox(height: 32),
                ]),
              )),
            ]),
          ),
    );
  }

  Widget _statCard(String label, String value, IconData icon, Color color) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: color.withOpacity(0.1)),
      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 10)],
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
        child: Icon(icon, color: color, size: 20),
      ),
      const Spacer(),
      Text(value, style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: color)),
      Text(label, style: const TextStyle(color: Colors.grey, fontSize: 12)),
    ]),
  );

  Widget _buildCourseTile(Map<String, dynamic> course) => Container(
    margin: const EdgeInsets.only(bottom: 10),
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: Colors.grey.shade100),
    ),
    child: Row(children: [
      Container(
        width: 42, height: 42,
        decoration: BoxDecoration(color: const Color(0xFF9333EA).withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
        child: const Icon(Icons.school, color: Color(0xFF9333EA), size: 20),
      ),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(course['name'] ?? '', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
        Text("${course['code']} · ${course['students']} students",
          style: const TextStyle(color: Colors.grey, fontSize: 11)),
      ])),
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        decoration: BoxDecoration(
          color: course['status'] == 'active' ? const Color(0xFFD1FAE5) : const Color(0xFFE0E7FF),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Text(
          (course['status'] ?? 'active').toUpperCase(),
          style: TextStyle(
            fontSize: 9, fontWeight: FontWeight.bold,
            color: course['status'] == 'active' ? const Color(0xFF065F46) : const Color(0xFF3730A3),
          ),
        ),
      ),
    ]),
  );

  Widget _buildSectionHeader(String title) => Text(title,
    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black54));

  Widget _buildWorkloadCard({
    required String label, required String value,
    String? subtext, required IconData icon, required Color color,
    String? buttonText, VoidCallback? onButtonPressed,
    String? linkText, VoidCallback? onLinkPressed,
  }) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: Colors.white, borderRadius: BorderRadius.circular(16),
      border: Border.all(color: const Color(0xFFF3F4F6)),
      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 10)],
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: const TextStyle(color: Colors.grey, fontSize: 13)),
          const SizedBox(height: 4),
          Row(children: [
            Text(value, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
            if (subtext != null) ...[
              const SizedBox(width: 8),
              Text(subtext, style: const TextStyle(color: Colors.grey, fontSize: 12)),
            ],
          ]),
        ])),
        Container(
          width: 48, height: 48,
          decoration: BoxDecoration(color: color.withOpacity(0.1), shape: BoxShape.circle),
          child: Icon(icon, color: color, size: 24),
        ),
      ]),
      if (buttonText != null) ...[
        const SizedBox(height: 16),
        SizedBox(width: double.infinity, child: ElevatedButton(
          onPressed: onButtonPressed,
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF9333EA),
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          ),
          child: Text(buttonText),
        )),
      ],
      if (linkText != null) ...[
        const SizedBox(height: 12),
        InkWell(onTap: onLinkPressed,
          child: Text(linkText, style: const TextStyle(color: Color(0xFF9333EA), fontWeight: FontWeight.w600))),
      ],
    ]),
  );

  Widget _buildFeatureButton({
    required String title, required String subtitle,
    required IconData icon, required List<Color> gradient, required VoidCallback onTap,
  }) => InkWell(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: gradient, begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: gradient[0].withOpacity(0.3), blurRadius: 12, offset: const Offset(0, 4))],
      ),
      child: Row(children: [
        Container(
          width: 56, height: 56,
          decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(12)),
          child: Icon(icon, color: Colors.white, size: 28),
        ),
        const SizedBox(width: 16),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
          Text(subtitle, style: const TextStyle(color: Colors.white70, fontSize: 12)),
        ])),
        const Icon(Icons.arrow_forward_ios, color: Colors.white54, size: 16),
      ]),
    ),
  );
}