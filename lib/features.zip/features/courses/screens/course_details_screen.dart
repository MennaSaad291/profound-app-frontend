import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

const String _base = 'http://127.0.0.1:8000';

class CourseDetailsDashboard extends StatefulWidget {
  const CourseDetailsDashboard({super.key});
  @override
  State<CourseDetailsDashboard> createState() => _CourseDetailsDashboardState();
}

class _CourseDetailsDashboardState extends State<CourseDetailsDashboard> {
  Map<String, dynamic>? analytics;
  Map<String, dynamic>? courseArgs;
  bool isLoading = true;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final args = ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
    if (args != null && courseArgs == null) {
      courseArgs = args;
      if (args.containsKey('id')) _fetchAnalytics(args['id']);
    }
  }

  Future<void> _fetchAnalytics(int courseId) async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse('$_base/course-analytics/$courseId'));
      if (res.statusCode == 200) {
        setState(() { analytics = jsonDecode(res.body); isLoading = false; });
      } else {
        setState(() => isLoading = false);
      }
    } catch (_) { setState(() => isLoading = false); }
  }

  @override
  Widget build(BuildContext context) {
    final args = courseArgs ?? {'code': 'N/A', 'name': 'Course Details'};

    return Scaffold(
      backgroundColor: const Color(0xFFF9FAFB),
      appBar: AppBar(
        title: Text(args['code'] ?? 'Course', style: GoogleFonts.inter(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            onPressed: () { if (args['id'] != null) _fetchAnalytics(args['id']); },
            icon: const Icon(Icons.refresh, color: Color(0xFF9333EA)),
          ),
        ],
      ),
      body: isLoading
        ? const Center(child: CircularProgressIndicator(color: Color(0xFF9333EA)))
        : RefreshIndicator(
            onRefresh: () async { if (args['id'] != null) await _fetchAnalytics(args['id']); },
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(children: [
                _buildIdentityHeader(args),
                const SizedBox(height: 16),
                _buildPerformanceOverview(),
                const SizedBox(height: 16),

                // No data state
                if (analytics?['average'] == 'N/A') ...[
                  _buildNoDataCard(),
                ] else ...[
                  _buildTrendCard(),
                  const SizedBox(height: 16),
                  _buildGradeDistribution(),
                ],
                const SizedBox(height: 32),
              ]),
            ),
          ),
    );
  }

  Widget _buildNoDataCard() => Container(
    padding: const EdgeInsets.all(32),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
    child: Column(children: [
      Icon(Icons.bar_chart, size: 64, color: Colors.grey.shade300),
      const SizedBox(height: 16),
      const Text("No Performance Data Yet",
        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text(
        "Upload a performance sheet with student grades and attendance to see analytics here.",
        textAlign: TextAlign.center,
        style: TextStyle(color: Colors.grey, fontSize: 13, height: 1.5),
      ),
      const SizedBox(height: 20),
      ElevatedButton.icon(
        onPressed: () => Navigator.pushNamed(context, '/upload_performance'),
        icon: const Icon(Icons.upload_file, color: Colors.white),
        label: const Text("Upload Performance Sheet", style: TextStyle(color: Colors.white)),
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF9333EA),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        ),
      ),
    ]),
  );

  Widget _buildIdentityHeader(Map<String, dynamic> args) => Container(
    width: double.infinity,
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(
      gradient: const LinearGradient(colors: [Color(0xFF9333EA), Color(0xFFD97706)]),
      borderRadius: BorderRadius.circular(18),
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(args['name'] ?? '',
        style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      Wrap(spacing: 16, children: [
        _headerChip(Icons.calendar_today, args['semester'] ?? 'N/A'),
        if ((args['room'] ?? 'TBA') != 'TBA') _headerChip(Icons.room, args['room']),
        if ((args['schedule'] ?? 'TBA') != 'TBA') _headerChip(Icons.access_time, args['schedule']),
        _headerChip(Icons.people, "${analytics?['total_students'] ?? args['students'] ?? 0} students"),
      ]),
    ]),
  );

  Widget _headerChip(IconData icon, dynamic label) => Row(mainAxisSize: MainAxisSize.min, children: [
    Icon(icon, color: Colors.white70, size: 14),
    const SizedBox(width: 4),
    Text("$label", style: const TextStyle(color: Colors.white70, fontSize: 12)),
  ]);

  Widget _buildPerformanceOverview() => Row(children: [
    _miniMetricCard("Average", analytics?['average'] ?? "N/A", const Color(0xFF9333EA), Icons.analytics),
    const SizedBox(width: 12),
    _miniMetricCard("At Risk", "${analytics?['at_risk'] ?? 0}", Colors.red, Icons.warning_amber),
    const SizedBox(width: 12),
    _miniMetricCard("Attendance", analytics?['avg_attendance'] ?? "N/A", const Color(0xFF10B981), Icons.how_to_reg),
  ]);

  Widget _miniMetricCard(String label, String val, Color color, IconData icon) => Expanded(
    child: Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white, borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(0.15)),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8)],
      ),
      child: Column(children: [
        Icon(icon, color: color, size: 18),
        const SizedBox(height: 4),
        Text(val, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: color)),
        Text(label, style: const TextStyle(color: Colors.grey, fontSize: 10)),
      ]),
    ),
  );

  Widget _buildTrendCard() {
    final List<dynamic> trend = analytics?['trend'] ?? [70, 75, 72, 80, 78];
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white, borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.trending_up, color: Color(0xFF9333EA), size: 18),
          const SizedBox(width: 8),
          const Text("Performance Trend", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
        ]),
        const SizedBox(height: 20),
        AspectRatio(
          aspectRatio: 1.7,
          child: LineChart(LineChartData(
            gridData: FlGridData(
              show: true, drawVerticalLine: false,
              getDrawingHorizontalLine: (v) => FlLine(color: Colors.grey[200]!, strokeWidth: 1),
            ),
            titlesData: FlTitlesData(
              rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
              topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
              bottomTitles: AxisTitles(sideTitles: SideTitles(
                showTitles: true,
                getTitlesWidget: (value, meta) {
                  final labels = ['W1', 'W2', 'W3', 'W4', 'W5'];
                  final idx = value.toInt();
                  if (idx >= 0 && idx < labels.length) {
                    return Text(labels[idx], style: const TextStyle(color: Colors.grey, fontSize: 10));
                  }
                  return const Text('');
                },
              )),
              leftTitles: AxisTitles(sideTitles: SideTitles(
                showTitles: true, reservedSize: 36,
                getTitlesWidget: (v, _) => Text(v.toInt().toString(),
                  style: const TextStyle(color: Colors.grey, fontSize: 10)),
              )),
            ),
            borderData: FlBorderData(show: true, border: Border(
              left: BorderSide(color: Colors.grey[400]!, width: 1),
              bottom: BorderSide(color: Colors.grey[400]!, width: 1),
            )),
            lineBarsData: [LineChartBarData(
              spots: trend.asMap().entries
                .map((e) => FlSpot(e.key.toDouble(), (e.value as num).toDouble())).toList(),
              isCurved: true,
              color: const Color(0xFF9333EA),
              barWidth: 3,
              dotData: const FlDotData(show: true),
              belowBarData: BarAreaData(show: true, color: const Color(0xFF9333EA).withOpacity(0.1)),
            )],
          )),
        ),
      ]),
    );
  }

  Widget _buildGradeDistribution() {
    final Map<String, dynamic> dist = analytics?['distribution'] ?? {"A": 0, "B": 0, "C": 0, "D": 0, "F": 0};
    final maxY = (dist.values.map((v) => (v as num).toDouble()).reduce((a, b) => a > b ? a : b) + 5).clamp(5.0, 100.0);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white, borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.bar_chart, color: Color(0xFF9333EA), size: 18),
          const SizedBox(width: 8),
          const Text("Grade Distribution", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
        ]),
        const SizedBox(height: 20),
        AspectRatio(
          aspectRatio: 1.8,
          child: BarChart(BarChartData(
            alignment: BarChartAlignment.spaceAround,
            maxY: maxY,
            titlesData: FlTitlesData(
              show: true,
              bottomTitles: AxisTitles(sideTitles: SideTitles(
                showTitles: true,
                getTitlesWidget: (value, meta) {
                  const labels = ['A', 'B', 'C', 'D', 'F'];
                  final idx = value.toInt();
                  return idx >= 0 && idx < labels.length
                    ? Text(labels[idx], style: const TextStyle(color: Colors.grey, fontSize: 12))
                    : const Text('');
                },
              )),
              leftTitles: AxisTitles(sideTitles: SideTitles(
                showTitles: true, reservedSize: 30,
                getTitlesWidget: (v, _) => Text(v.toInt().toString(),
                  style: const TextStyle(color: Colors.grey, fontSize: 10)),
              )),
              topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
              rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            ),
            gridData: FlGridData(show: true, drawVerticalLine: false,
              getDrawingHorizontalLine: (v) => FlLine(color: Colors.grey[100]!, strokeWidth: 1)),
            borderData: FlBorderData(show: true, border: Border(
              left: BorderSide(color: Colors.grey[400]!, width: 1),
              bottom: BorderSide(color: Colors.grey[400]!, width: 1),
            )),
            barGroups: [
              _makeBar(0, (dist['A'] as num).toDouble(), Colors.green),
              _makeBar(1, (dist['B'] as num).toDouble(), Colors.blue),
              _makeBar(2, (dist['C'] as num).toDouble(), Colors.amber),
              _makeBar(3, (dist['D'] as num).toDouble(), Colors.orange),
              _makeBar(4, (dist['F'] as num).toDouble(), Colors.red),
            ],
          )),
        ),
        const SizedBox(height: 16),
        Wrap(spacing: 12, runSpacing: 8, children: [
          _legendItem("A (90-100)", Colors.green),
          _legendItem("B (80-89)", Colors.blue),
          _legendItem("C (70-79)", Colors.amber),
          _legendItem("D (60-69)", Colors.orange),
          _legendItem("F (<60)", Colors.red),
        ]),
      ]),
    );
  }

  BarChartGroupData _makeBar(int x, double y, Color color) => BarChartGroupData(
    x: x,
    barRods: [BarChartRodData(
      toY: y, color: color, width: 20,
      borderRadius: const BorderRadius.vertical(top: Radius.circular(6)),
      backDrawRodData: BackgroundBarChartRodData(show: true, toY: 30, color: Colors.grey[50]),
    )],
  );

  Widget _legendItem(String label, Color color) => Row(mainAxisSize: MainAxisSize.min, children: [
    Container(width: 10, height: 10, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
    const SizedBox(width: 4),
    Text(label, style: const TextStyle(fontSize: 10, color: Colors.grey)),
  ]);
}