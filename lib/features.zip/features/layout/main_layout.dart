import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class MainLayout extends StatelessWidget {
  final Widget child;
  final String title;
  final List<Widget>? actions;

  const MainLayout({
    super.key,
    required this.child,
    this.title = "Profound",
    this.actions,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: _buildSidebar(context),
      appBar: AppBar(
        // ✅ Single leading: only hamburger, never back button
        leadingWidth: 56,
        leading: Builder(
          builder: (ctx) => IconButton(
            icon: const Icon(Icons.menu, color: Colors.white),
            onPressed: () => Scaffold.of(ctx).openDrawer(),
          ),
        ),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF7E22CE), Color(0xFF9333EA), Color(0xFFD97706)],
            ),
          ),
        ),
        centerTitle: true,
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(2),
              decoration: const BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
              ),
              child: const CircleAvatar(
                radius: 18,
                backgroundColor: Colors.white,
                backgroundImage: AssetImage('assets/images/logo.jpeg'),
              ),
            ),
            const SizedBox(width: 10),
            Text.rich(
              TextSpan(children: const [
                TextSpan(text: "Prof", style: TextStyle(color: Colors.white)),
                TextSpan(text: "ound", style: TextStyle(color: Color(0xFFD97706))),
              ]),
              style: GoogleFonts.inter(fontSize: 22, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        // ✅ Pass optional action buttons from pages
        actions: actions,
        elevation: 0,
      ),
      body: child,
    );
  }

  Widget _buildSidebar(BuildContext context) {
    final String? currentRoute = ModalRoute.of(context)?.settings.name;
    return Drawer(
      width: 280,
      backgroundColor: Colors.white,
      child: Column(children: [
        DrawerHeader(
          decoration: const BoxDecoration(color: Colors.white),
          child: Row(children: [
            const CircleAvatar(
              radius: 18,
              backgroundColor: Colors.white,
              backgroundImage: AssetImage('assets/images/logo.jpeg'),
            ),
            const SizedBox(width: 12),
            Text.rich(
              TextSpan(children: const [
                TextSpan(text: "Prof", style: TextStyle(color: Color(0xFF7E22CE))),
                TextSpan(text: "ound", style: TextStyle(color: Color(0xFFD97706))),
              ]),
              style: GoogleFonts.inter(fontSize: 22, fontWeight: FontWeight.bold),
            ),
          ]),
        ),
        Expanded(
          child: ListView(padding: EdgeInsets.zero, children: [
            _navItem(context, Icons.grid_view_rounded,    "Dashboard",          '/dashboard', currentRoute),
            _navItem(context, Icons.book_outlined,         "My Courses",         '/courses',   currentRoute),
            _navItem(context, Icons.assignment_outlined,   "Grading",            '/grading',   currentRoute),
            _navItem(context, Icons.analytics_outlined,    "Analytics & Reports", '/analytics', currentRoute),
            _navItem(context, Icons.person_outline,        "Academic Profile",   '/profile',   currentRoute),
            _navItem(context, Icons.science_outlined,      "Research",           '/research',  currentRoute),
            _navItem(context, Icons.settings_outlined,     "Settings",           '/settings',  currentRoute),
          ]),
        ),
        const Divider(indent: 20, endIndent: 20),
        ListTile(
          leading: const Icon(Icons.logout, color: Colors.redAccent),
          title: const Text("Logout",
            style: TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold)),
          onTap: () => _showLogoutDialog(context),
        ),
        const SizedBox(height: 20),
      ]),
    );
  }

  Widget _navItem(BuildContext context, IconData icon, String label,
      String route, String? currentRoute) {
    final isActive = currentRoute == route;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      child: Container(
        decoration: BoxDecoration(
          color: isActive ? const Color(0xFF9333EA) : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
        ),
        child: ListTile(
          leading: Icon(icon,
            color: isActive ? Colors.white : Colors.grey[600], size: 22),
          title: Text(label,
            style: GoogleFonts.inter(
              color: isActive ? Colors.white : Colors.black87,
              fontWeight: isActive ? FontWeight.w600 : FontWeight.w400,
              fontSize: 14,
            )),
          onTap: () {
            if (!isActive) {
              final args = ModalRoute.of(context)?.settings.arguments;
              Navigator.pop(context); // close drawer
              Navigator.pushReplacementNamed(context, route, arguments: args);
            } else {
              Navigator.pop(context); // just close drawer
            }
          },
        ),
      ),
    );
  }

  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text("Confirm Logout"),
        content: const Text("Are you sure you want to log out?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text("Cancel"),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent),
            onPressed: () =>
              Navigator.pushNamedAndRemoveUntil(ctx, '/login', (_) => false),
            child: const Text("Logout", style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }
}