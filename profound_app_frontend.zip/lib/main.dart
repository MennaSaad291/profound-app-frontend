import 'package:flutter/material.dart';
import 'features/auth/screens/login_screen.dart';
import 'features/auth/screens/signup_screen.dart';
import 'features/auth/screens/profile_screen.dart';
import 'features/courses/screens/courses_list_screen.dart';
import 'features/courses/screens/ai_exam_generator.dart';
import 'features/courses/screens/course_details_screen.dart';
import 'features/courses/screens/ai_lecture_screen.dart';
import 'features/dashboard/screens/professor_dashboard.dart';
import 'features/layout/main_layout.dart';
import 'features/grading/ai_grading_module.dart';
import 'features/analytics/full_analytics_reports_module.dart';
import 'features/research/screens/research_organizer_screen.dart';
import 'features/settings/screens/system_settings_screen.dart';

void main() {
  runApp(const ProfoundApp());
}

class ProfoundApp extends StatelessWidget {
  const ProfoundApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Profound',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF1E3A8A)),
      ),
      routes: {
        '/login': (context) => const LoginScreen(),
        '/signup': (context) => const SignUpForm(),
        '/profile': (context) => const MainLayout(child: ProfessorProfileScreen()),
        '/courses': (context) => const MainLayout(child: CoursesListScreen()),
        '/course_details': (context) => const MainLayout(child: CourseDetailsDashboard()),
        '/dashboard': (context) => const MainLayout(child: ProfessorDashboard()),
        '/grading': (context) {
          final args = ModalRoute.of(context)?.settings.arguments;
          int finalUserId = 1;

          if (args is int) {
            finalUserId = args;
          } else if (args is Map) {
            finalUserId = args['id'] ?? args['user_id'] ?? args['userId'] ?? 1;
          }

          debugPrint("=== Unifying Routes to Private Space for User ID: $finalUserId ===");
          return MainLayout(child: AiGradingModule(userId: finalUserId));
        },        '/analytics': (context) {
          final args = ModalRoute.of(context)?.settings.arguments;
          String? preSelected;
          if (args is Map) preSelected = args['course']?.toString();
          return MainLayout(
            child: FullAnalyticsReportsModule(
              onBack: () => Navigator.of(context).pop(),
              preSelectedCourse: preSelected,
            ),
          );
        },
        '/research': (context) => const MainLayout(child: ResearchOrganizerScreen()),
        '/settings': (context) {
          final args = ModalRoute.of(context)?.settings.arguments;
          int userId = 0;
          if (args is Map) {
            userId = (args['id'] ?? args['user_id'] ?? 0) as int;
          }
          return MainLayout(child: SystemSettingsScreen(userId: userId));
        },
        '/generate_lecture': (context) => const MainLayout(child: AILectureScreen()),
        '/exam_generator': (context) => const MainLayout(child: AIExamGenerator()),
      },
      home: const LoginScreen(),

    );
  }
}